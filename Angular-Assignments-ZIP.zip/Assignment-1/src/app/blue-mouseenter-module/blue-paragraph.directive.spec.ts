import { BlueParagraphDirective } from './blue-paragraph.directive';

describe('BlueParagraphDirective', () => {
  it('should create an instance', () => {
    const directive = new BlueParagraphDirective();
    expect(directive).toBeTruthy();
  });
});
