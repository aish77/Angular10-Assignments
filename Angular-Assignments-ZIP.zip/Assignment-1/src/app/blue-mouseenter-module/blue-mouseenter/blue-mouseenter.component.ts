import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blue-mouseenter',
  templateUrl: './blue-mouseenter.component.html',
  styleUrls: ['./blue-mouseenter.component.css']
})
export class BlueMouseenterComponent {


  hover = false;



}
